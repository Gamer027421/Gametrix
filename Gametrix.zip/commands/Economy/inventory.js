const { MessageEmbed } = require('discord.js');
const db = require('quick.db');

module.exports = {
    name: 'inventory',
    description: "View Your Inventory",
    aliases: ['inven', 'int', 'inv'],
    usage: "[prefix]inventory",
    run: async(client, message, args) => {

        let gun = db.fetch(`gun_${message.guild.id}_${message.author.id}`)
        if( gun  === null) gun = "0";

        let fishingrod = db.fetch(`fishingrod_${message.guild.id}_${message.author.id}`)
        if( fishingrod  === null) fishingrod = "0";
        
        let fish= db.fetch(`fish_${message.guild.id}_${message.author.id}`)
        if( fish  === null) fish = "0";
        const Embed = new MessageEmbed()
        .setTitle('Inventory')
        .addField('`Gun`🔫', gun)
        .addField('`Fishing rod`🎣', fishingrod)
        .addField('`Fish`🐟', fish)
        .setColor("RANDOM")

        message.channel.send(Embed)
    }
}