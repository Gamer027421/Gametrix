const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
  name:'removemoney',
  description: 'Remove Money from User Balance',
  aliases: 'removem',
run:async (bot, message, args, member) => {
 if (!args[0]) return message.reply('You Must Enter a Value');

 if (!message.member.permissions.has('ADMINISTRATOR')) {
  return message.reply('You Dont have the perms to do this');
 }

 if (isNaN(args[1])) return;
    
let user = message.mentions.users.first(); 
 db.subtract(`money_${message.guild.id}_${user.id}`, args[1])


 let moneyEmbed = new Discord.MessageEmbed()
  .setColor('RANDOM')
  .setDescription(
   `✅ | ${args[1]} Subtracted from  ${user}.`
  );
 message.channel.send(moneyEmbed);
}};