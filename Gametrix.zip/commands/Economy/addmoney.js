const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
  name:'addmoney',
  description: 'Add Money to User Balance',
  aliases: 'addm',
run:async (bot, message, args, member) => {
 if (!args[0]) return message.reply('You Must Enter a Value');

 if (!message.member.permissions.has('ADMINISTRATOR')) {
  return message.reply('You Dont have the perms to do this');
 }

 if (isNaN(args[1])) return;
    
let user = message.mentions.users.first(); 
 db.add(`money_${message.guild.id}_${user.id}`, args[1])


 let moneyEmbed = new Discord.MessageEmbed()
  .setColor('RANDOM')
  .setDescription(
   `✅ | ${args[1]} Added for  ${user}.`
  );
 message.channel.send(moneyEmbed);
}};