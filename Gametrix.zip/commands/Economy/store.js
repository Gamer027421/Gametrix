const { MessageEmbed } = require('discord.js');
const db = require('quick.db');

module.exports = {
    name: 'store',
    description: "Store",
    aliases: ['shop'],
    usage: "[prefix]store",
    run: async(client, message, args) => {

        const embed = new MessageEmbed()
        .setTitle('Store')
        .setColor("RANDOM")
        .addField('**gun**', "**Gives you ability to Rob other users, Buy This for 10000\n Sell:5000**")       
       .addField('**Fishing Rod**' , "**Go Out Fishing!, costs 1000 \n Sell: 500**")
       .addField(`**Fish**`, "**This Item Can Only be Sold For 50**") 
        message.channel.send(embed)
    }
}