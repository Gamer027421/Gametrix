const db = require('quick.db');
const ms = require("parse-ms");
const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'fish',
    description: "Collect Fish From your Fishing Setup",
    usage: "[prefix]fish",
    cooldowns: 3600000 ,
    run: async(client, message, args) => {     
        let amount = Math.floor(Math.random() * 10);
        let user = message.author
       
       
       let rods = db.fetch(`fishingrod_${message.guild.id}_${user.id}`)
        if(rods == 0){
          const embed = new MessageEmbed()
            .setDescription("You Don\'t Have a Fishing rod, Make sure you buy one from the Store!")
            .setColor("RANDOM")

            return message.channel.send(embed)
        }

                
        else {
           
            db.add(`fish_${message.guild.id}_${user.id}`, amount)
            db.set(`timeout_${message.guild.id}_${user.id}`, Date.now())

            const dailySuccess = new MessageEmbed()
            .setDescription(`You got ${amount} Fish `)
            .setColor("RANDOM")

            message.channel.send(dailySuccess)
        }
    }

}