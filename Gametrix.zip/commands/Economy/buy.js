const { MessageEmbed } = require("discord.js");
const db = require('quick.db');

module.exports = {
    name: 'buy',
    description: "Buy Items from the Shop",
    aliases: [],
    usage: "[prefix]buy [item]",
    run: async(client, message, args) => {
        let purchase = args.join(" ")
        let cash = await db.fetch(`money_${message.guild.id}_${message.author.id}`)

        if(!purchase) {
            const buyError = new MessageEmbed()
            .setDescription("Please specify an item")
            .setColor("RANDOM")

            return message.channel.send(buyError)
        }
        let items = await db.fetch(`items_${message.guild.id}_${message.author.id}`, {items: []})

        if(purchase == 'gun') {
            if(cash < 10000) {
                const purchaseError = new MessageEmbed()
                .setDescription("You Don\'t Have Enough Money to Buy a Gun!")
                .setColor("#ff0033")

                return message.channel.send(purchaseError)
            }

            db.subtract(`money_${message.guild.id}_${message.author.id}`, 10000)
            db.add(`gun_${message.guild.id}_${message.author.id}`, 1)

            const purchaseThiefOutfitSuccess = new MessageEmbed()
            .setDescription(`Successfuly Bought One Gun for \$10000 , Damn mans got a gun`)
            .setColor("5ac247")

            message.channel.send(purchaseThiefOutfitSuccess)
        }
            
        
      
     if(purchase== 'fishing rod'){
     if(cash<1000){
        const purchaseError = new MessageEmbed()
        .setDescription("You Don\'t Have Enough Money to Buy a Fishing Rod")
        .setColor("#ff0033")
     return message.channel.send(purchaseError)
      }
       db.subtract(`money_${message.guild.id}_${message.author.id}`, 1000)
       db.add(`fishingrod_${message.guild.id}_${message.author.id}`, 1)
    
    
    
    
    const rod = new MessageEmbed()
            .setDescription(`Successfuly Bought One Fishing Rod for \$1000`)
            .setColor("#5ac247")
    
    message.channel.send(rod)
    }
}
}