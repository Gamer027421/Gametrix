const { MessageEmbed } = require("discord.js");
const db = require('quick.db');

module.exports = {
    name: 'sell',
    description: "Sell Items in the Shop",
    aliases: [],
    usage: "[prefix]sell [item]",
    run: async(client, message, args) => {
        let purchase = args.join(" ")
        let cash = await db.fetch(`money_${message.guild.id}_${message.author.id}`)

        if(!purchase) {
            const buyError = new MessageEmbed()
            .setDescription("Please specify an item")
            .setColor("RANDOM")

            return message.channel.send(buyError)
        }
        let items = await db.fetch(`items_${message.guild.id}_${message.author.id}`, {items: []})

let gun = db.fetch(`gun_${message.guild.id}_${message.author.id}`)
        
        if(purchase == 'gun') {
         if(gun > 0) {
            

            db.add(`money_${message.guild.id}_${message.author.id}`, 5000)
            db.subtract(`gun_${message.guild.id}_${message.author.id}`, 1)

            const purchaseThiefOutfitSuccess = new MessageEmbed()
            .setDescription(`Successfuly Sold One Gun for \$5000`)
            .setColor("5ac247")

            message.channel.send(purchaseThiefOutfitSuccess)
        }
        }
            
      let fishrod =  db.fetch(`fishingrod_${message.guild.id}_${message.author.id}`)
      
     if(purchase== 'fishing rod'){ if(fishrod > 0){
      
      
       db.add(`money_${message.guild.id}_${message.author.id}`, 500)
       db.subtract(`fishingrod_${message.guild.id}_${message.author.id}`, 1)
    
    
    
    
    const rod = new MessageEmbed()
            .setDescription(`Successfuly Sold One Fishing Rod for \$500`)
            .setColor("#5ac247")
    
    message.channel.send(rod)
    }
}
      let fish =  db.fetch(`fish_${message.guild.id}_${message.author.id}`)
     
     if(purchase== 'fish'){ if(fish > 0){
       if(args[1] === "all") args[1] = fish 
      
       db.add(`money_${message.guild.id}_${message.author.id}`, 50)
       db.subtract(`fish_${message.guild.id}_${message.author.id}`, 1)
    
    
    
    
    const sfish = new MessageEmbed()
            .setDescription(`Successfuly Sold One Fish for 50`)
            .setColor("#5ac247")
    
    message.channel.send(sfish)
    }
}
    }
}