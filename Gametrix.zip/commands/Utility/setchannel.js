const { MessageEmbed } = require('discord.js');
const db = require('quick.db');

module.exports = {
    name: "setchannel",
    category: "Suggestions",
    description: "Set a channel for events.",
    aliases: ["sc"],
    usage: "setchannel <event> <channel>",
    userPermissions: ["MANAGE_CHANNELS"],
    run: async(client, message, args) => {
        if(args[0] === "suggestions") {
        if(!message.member.hasPermission('ADMINISTRATOR')) {
            const noPerms = new MessageEmbed()
            .setDescription(`You don\'t have permissions to Config the bot.`)
            .setColor("RANDOM")
            return message.channel.send(noPerms)
        } 
            
            let channel = message.mentions.channels.first()
            if(!channel) {
                const noChannel = new MessageEmbed()
                .setDescription(`Please mention a channel`)
                .setColor("RANDOM")
                .setFooter(message.author.username, message.author.displayAvatarURL())

                return message.channel.send(noChannel)        
               
            }

            db.set(`suggestionChannel_${message.guild.id}`, channel.id)
            db.set(`suggest_${message.guild.id}.setchannel`, 'enabled')
            const success = new MessageEmbed()
            .setDescription(`Set the suggestion channel to ${channel}`)
            .setColor("RANDOM")
            .setFooter(message.author.username, message.author.displayAvatarURL())

            return message.channel.send(success)
        } else {
            const noArgs = new MessageEmbed()
            .setDescription(`Please provide a valid event\n\nValid Events: \`suggestions\``)
            .setColor("RANDOM")
            .setFooter(`Gametrix`, client.user.displayAvatarURL())

            return message.channel.send(noArgs)
               
            
        }
    }
}