const pagination = require('discord.js-pagination');
const Discord = require('discord.js');

module.exports = {
    name: "help",
    description: "Help Desk",

    async run (client, message, args){

        const fun = new Discord.MessageEmbed()
        .setTitle('🕹 Fun Commands')
        .addField('`8ball`', '<a:rgbpoint:915544463034683453> Answers your question')
        .addField('`advice`', '<a:rgbpoint:915544463034683453> Gives you a random advice')         
        .addField('`dm`', '<a:rgbpoint:915544463034683453> DM a user in guild')
        .setColor('RANDOM')
        .setTimestamp()

        const economy = new Discord.MessageEmbed()
        .setTitle('💵 Economy Commands')
        .addField('`balance`', '<a:rgbpoint:915544463034683453> Check your bank and wallet balance')
        .addField('`buy`', '<a:rgbpoint:915544463034683453> Buy something from store')
        .addField('`daily`', '<a:rgbpoint:915544463034683453> Collect your Daily Cash')
        .addField('`deposit`', '<a:rgbpoint:915544463034683453> Deposit your wallet balance to your bank account')
        .addField('`inventory`', '<a:rgbpoint:915544463034683453> Check your Inventory/Backpack')
        .addField('`pay`', '<a:rgbpoint:915544463034683453> Pay someone cash')
        .addField('`rob`', '<a:rgbpoint:915544463034683453> Rob someones wallet balance [You need Gun to use this command, buy one from store]')
        .addField('`store`', '<a:rgbpoint:915544463034683453> Check store')
        .addField('`withdraw`', '<a:rgbpoint:915544463034683453> Withdraw some amount from your bank account')
        .addField('`work`', '<a:rgbpoint:915544463034683453> Work for money')
        .addField('`leaderboard`','<a:rgbpoint:915544463034683453> Get User Money LeaderBoard!')
        .addField('`sell`','<a:rgbpoint:915544463034683453> Sell items')
        .setColor('RANDOM')
        .setTimestamp()

        const moderation = new Discord.MessageEmbed()
        .setTitle('🛠 Moderation Commands')
        .addField('`addrole`', '<a:rgbpoint:915544463034683453> Add a role on someone')
        .addField('`ban / unban / idban`', '<a:rgbpoint:915544463034683453> Ban someone / Unban someone / Ban an ID')
        .addField('`clear`', '<a:rgbpoint:915544463034683453> Purge Commands')
        .addField('`disablewelcome / setwelcome`', '<a:rgbpoint:915544463034683453> Disable / Enable welcome message')
        .addField('`kick`', '<a:rgbpoint:915544463034683453> Kick someone')
        .addField('`lockchannel / unlockchannel`', '<a:rgbpoint:915544463034683453> Lock / Unlock channel')
        .addField('`mute / unmute`', '<a:rgbpoint:915544463034683453> Mute someone / Unmute someone')
        .addField('`say`', '<a:rgbpoint:915544463034683453> Control the Bot by making it say anything')
        .addField('`shutdown`', '<a:rgbpoint:915544463034683453> Owner Command Only')
        .addField('`slowmode`', '<a:rgbpoint:915544463034683453> Add a slowmode to a channel')
        .addField('`warn / unwarn`', '<a:rgbpoint:915544463034683453> Warn someone / Unwarn someone')
        .addField('`warnings`', '<a:rgbpoint:915544463034683453> Check someones warnings')
        .addField('addmoney/removemoney','<a:rgbpoint:915544463034683453> Add/remove Money to/from User')
       .setColor('RANDOM')
        .setTimestamp()

        const memes = new Discord.MessageEmbed()
        .setTitle('🗿 Meme Commands')
        .addField('`facepalm`', '<a:rgbpoint:915544463034683453> smh')
        .addField('`meme`', '<a:rgbpoint:915544463034683453> LOL')
        .addField('`shit`', '<a:rgbpoint:915544463034683453> step on shit [Mention Someone]')
        .addField('`slap`', '<a:rgbpoint:915544463034683453> Slap someone [Mention Someone]')
        .setColor('RANDOM')
        .setTimestamp()
        
        const music = new Discord.MessageEmbed()
        .setTitle('🎵 Music Commands')
        .addField('`autoplay`', '<a:rgbpoint:915544463034683453> Turn Autoplay on / off')
        .addField('`filter`', '<a:rgbpoint:915544463034683453> Add different filters to your song')
        .addField('`join / leave`', '<a:rgbpoint:915544463034683453> Make the bot join VC / Make the bot leave VC')
        .addField('`loop`', '<a:rgbpoint:915544463034683453> Turn Loop filters on / off')
        .addField('`resume / pause`', '<a:rgbpoint:915544463034683453> Resume / Pause')
        .addField('`queue`', '<a:rgbpoint:915544463034683453> Queue')
        .addField('`play`', '<a:rgbpoint:915544463034683453> Play a song')
        .addField('`seek`', '<a:rgbpoint:915544463034683453> Seek')
        .addField('`skip`', '<a:rgbpoint:915544463034683453> Skip')
        .addField('`stop`', '<a:rgbpoint:915544463034683453> Stop')
        .addField('`volume`', '<a:rgbpoint:915544463034683453> Change Volume')
        .setColor('RANDOM')
        .setTimestamp()

        const nsfw = new Discord.MessageEmbed()
        .setTitle('♥ Anime Commands')
        .addField('`afind`','<a:rgbpoint:915544463034683453> Search For Anime')
        .addField('`waifu`', '<a:rgbpoint:915544463034683453> Wafius At Your Service')
        .addField('`wallpaper`','<a:rgbpoint:915544463034683453> Get Anime Wallpapers!')
        .setColor('RANDOM')
        .setTimestamp()

        const giveaway = new Discord.MessageEmbed()
        .setTitle('🎉 Giveaway Commands')
        .addField('`start`', '<a:rgbpoint:915544463034683453> Host a giveaway:')
        .addField('`reroll`', '<a:rgbpoint:915544463034683453> Reroll a giveaway')
        .addField('`end`', '<a:rgbpoint:915544463034683453> End a giveaway')
        .setColor('RANDOM')
        .setTimestamp()

        const utility = new Discord.MessageEmbed()
        .setTitle('🔰 Utility Commands')
        .addField('`avatar`', '<a:rgbpoint:915544463034683453> Check someones avatar')
        .addField('`calculator`', '<a:rgbpoint:915544463034683453> Solve your maths homework')
        .addField('`config`', '<a:rgbpoint:915544463034683453> Check guilds config')
        .addField('`help`', '<a:rgbpoint:915544463034683453> Help desk')
        .addField('`ping`', '<a:rgbpoint:915544463034683453> Pong')
        .addField('`rank`', '<a:rgbpoint:915544463034683453> Check someones rank')
        .addField('`serverinfo / userinfo`', '<a:rgbpoint:915544463034683453> Check guilds info / Check someones info')
        .addField('`weather`', '<a:rgbpoint:915544463034683453> Check weather of a location')
        .addField('`Uptime`','<a:rgbpoint:915544463034683453> Get Current Onlinetime of The Bot!' )
        .addField('`Suggest`','<a:rgbpoint:915544463034683453> Make A Bot Suggestion')       
        .addField('`afk`','<a:rgbpoint:915544463034683453> Set Afk status')
        .setColor('RANDOM')
        .setTimestamp()

        

        const pages = [
                fun,
                economy,
                moderation,
                memes,
                music,
                nsfw,
                giveaway,
                utility,
                
        ]

        const emojiList = ["◀", "▶"];

        const timeout = '120000';

        pagination(message, pages, emojiList, timeout)
    }
}